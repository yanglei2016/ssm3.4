﻿
I.mq
cd C:\DingSai\Tools\RocketMQ\alibaba-rocketmq\bin

start/b mqnamesrv.exe >C:\DingSai\Tools\RocketMQ\alibaba-rocketmq\bin\mp_log.log

II.mq启动broker 
cd C:\DingSai\Tools\RocketMQ\alibaba-rocketmq\bin

start/b mqbroker.exe -n "127.0.0.1:9876">C:\DingSai\Tools\RocketMQ\alibaba-rocketmq\bin\mq_log_mqbroker.log
II.mq
可以通过jps查看一下是不是有了RocketMQ的进程，如下方的6484 
C:\Users\houchangren>jps -v  


II.mq关闭 
 查看端口号占用
     netstat -aon|findstr "9876"
taskkill -f -t -im mqnamesrv.exe
